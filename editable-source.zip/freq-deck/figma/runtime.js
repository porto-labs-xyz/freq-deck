// Offline native Figma import. Generated data and image bytes are prepended by build.mjs.
function paint(hex){if(!hex)return [];let nums;if(hex[0]==='#'){let s=hex.slice(1);nums=[0,2,4].map(i=>parseInt(s.slice(i,i+2),16));}else nums=(hex.match(/[\d.]+/g)||[]).map(Number);return nums.length>=3?[{type:'SOLID',color:{r:nums[0]/255,g:nums[1]/255,b:nums[2]/255},opacity:nums[3]===undefined?1:nums[3]}]:[];}
async function run(){
 const fonts={},missing=[],hashes={};
 const families=[...new Set(SLIDES.flatMap(s=>s.elements.filter(e=>e.style).map(e=>e.style.typeface)))];
 await figma.loadFontAsync({family:'Inter',style:'Regular'});
 for(const family of families){try{await figma.loadFontAsync({family,style:'Regular'});fonts[family]={family,style:'Regular'};}catch(e){fonts[family]={family:'Inter',style:'Regular'};missing.push(family);}}
 for(const key of Object.keys(IMAGES))hashes[key]=figma.createImage(figma.base64Decode(IMAGES[key])).hash;
 const page=figma.createPage();page.name='FREQ / Deck / 20 October 2026';await figma.setCurrentPageAsync(page);const frames=[];
 for(let i=0;i<SLIDES.length;i++){
  const s=SLIDES[i],frame=figma.createFrame();page.appendChild(frame);frame.name=String(i+1).padStart(2,'0')+' / '+(s.elements.find(e=>e.kind==='textbox'&&e.style.fontSize>=40)?.text||'FREQ').replace(/\n/g,' ');frame.resize(1280,720);frame.x=(i%3)*1360;frame.y=Math.floor(i/3)*800;frame.fills=paint(s.slide.backgroundColor);frame.clipsContent=true;frames.push(frame);
  for(const e of s.elements){let n;const p=e.position;
   if(e.svg){n=figma.createNodeFromSvg(e.svg);frame.appendChild(n);n.resize(p.width,Math.max(1,p.height));}
   else if(e.kind==='textbox'){n=figma.createText();frame.appendChild(n);n.fontName=fonts[e.style.typeface];n.fontSize=e.style.fontSize;n.characters=e.text;n.fills=paint(e.style.color);n.resize(p.width,Math.max(1,p.height));n.textAutoResize='HEIGHT';n.lineHeight={unit:'PERCENT',value:120};n.textAlignHorizontal=(e.style.alignment||'left').toUpperCase();}
   else if(e.kind==='image'){
    n=figma.createFrame();frame.appendChild(n);n.resize(p.width,p.height);n.fills=[];n.clipsContent=true;if(e.geometry==='ellipse')n.cornerRadius=Math.min(p.width,p.height)/2;
    const c=e.crop||{},l=c.left||0,t=c.top||0,r=c.right||0,b=c.bottom||0,cw=1-l-r,ch=1-t-b;const img=figma.createRectangle();n.appendChild(img);img.name=e.alt||'Image';img.resize(p.width/cw,p.height/ch);img.x=-l*p.width/cw;img.y=-t*p.height/ch;img.fills=[{type:'IMAGE',imageHash:hashes[e.src],scaleMode:e.fit==='contain'?'FIT':'FILL'}];
   }else{n=e.geometry==='ellipse'?figma.createEllipse():figma.createRectangle();frame.appendChild(n);n.resize(Math.max(1,p.width),Math.max(1,p.height));n.fills=paint(e.fillColor);if(e.geometry==='roundRect')n.cornerRadius=Math.min(20,p.width/2,p.height/2);if(e.lineWidth){n.strokes=paint(e.lineColor);n.strokeWeight=e.lineWidth;n.strokeAlign='INSIDE';}}
   n.name=e.name||e.alt||e.kind;n.x=p.left;n.y=p.top;n.setPluginData('sourceElement',e.id);
  }
 }
 figma.currentPage.selection=frames;figma.viewport.scrollAndZoomIntoView(frames);
 figma.closePlugin('Imported 15 editable slides.'+(missing.length?' Font substitutions: '+missing.join(', ')+'. Install these fonts and re-import for fidelity.':''));
}
run().catch(e=>{figma.notify(String(e),{error:true});figma.closePlugin('Import failed: '+String(e));});
