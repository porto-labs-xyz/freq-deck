const wraps=[...document.querySelectorAll('.slide-wrap')];let current=0;
function resize(){const scale=Math.min((innerWidth-(document.body.classList.contains('presenting')?0:40))/1280,1);for(const w of wraps){w.style.width=1280*scale+'px';w.style.height=720*scale+'px';w.firstElementChild.style.transform=`scale(${scale})`;}}
function select(){wraps.forEach((w,i)=>w.classList.toggle('active',i===current));}
document.querySelector('#present').onclick=()=>{document.body.classList.toggle('presenting');select();resize();};
addEventListener('keydown',e=>{if(e.key==='Escape'){document.body.classList.remove('presenting');resize();}if(document.body.classList.contains('presenting')&&['ArrowRight','ArrowLeft',' '].includes(e.key)){e.preventDefault();current=Math.max(0,Math.min(14,current+(e.key==='ArrowLeft'?-1:1)));select();}});addEventListener('resize',resize);resize();
