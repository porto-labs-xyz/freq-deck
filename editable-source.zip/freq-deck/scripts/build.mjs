import fs from 'node:fs/promises';
const slides=JSON.parse(await fs.readFile(new URL('../source/slides.json',import.meta.url),'utf8'));
const root=new URL('../',import.meta.url);
const esc=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('"','&quot;');
const box=p=>`left:${p.left}px;top:${p.top}px;width:${p.width}px;height:${Math.max(p.height,1)}px;`;
function element(e){
 const p=e.position,st=e.style||{},id=esc(e.id),name=esc(e.name||e.alt||e.kind);let style=box(p);
 if(e.svg)return `<div class="element vector" data-id="${id}" aria-label="${name}" style="${style}">${e.svg}</div>`;
 if(e.kind==='textbox')return `<div class="element text" data-id="${id}" style="${style}font-family:'${esc(st.typeface)}',sans-serif;font-size:${st.fontSize}px;color:${st.color};text-align:${st.alignment||'left'};${st.bold?'font-weight:700;':''}">${esc(e.text)}</div>`;
 if(e.kind==='image'){
  const c=e.crop||{},l=c.left||0,t=c.top||0,r=c.right||0,b=c.bottom||0,w=1-l-r,h=1-t-b;
  return `<div class="element image" data-id="${id}" style="${style}${e.geometry==='ellipse'?'border-radius:50%;':''}"><img alt="${name}" src="${e.src}" style="left:${-l/w*100}%;top:${-t/h*100}%;width:${100/w}%;height:${100/h}%;object-fit:${e.fit==='contain'?'contain':'cover'}"></div>`;
 }
 return `<div class="element shape" data-id="${id}" aria-label="${name}" style="${style}background:${e.fillColor||'transparent'};border:${e.lineWidth||0}px solid ${e.lineColor||'transparent'};border-radius:${e.geometry==='ellipse'?'50%':e.geometry==='roundRect'?'20px':'0'}"></div>`;
}
const main=slides.map(s=>`<section class="slide-wrap" id="slide-${s.number}" aria-label="Slide ${s.number}"><div class="slide" style="background:${s.slide.backgroundColor}">${s.elements.map(element).join('\n')}</div></section>`).join('\n');
await fs.writeFile(new URL('index.html',root),`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>FREQ by Porto Labs</title><link rel="stylesheet" href="deck.css"></head><body><nav><strong>FREQ / PORTO LABS</strong><a href="reference/FREQ-2026-10-20.pdf">Reference PDF</a><a href="README.md">Figma handoff</a><button id="present">Present</button></nav><main>${main}</main><script src="viewer.js"></script></body></html>`);
const embedded={};for(const s of slides)for(const e of s.elements)if(e.src&&!embedded[e.src])embedded[e.src]=(await fs.readFile(new URL(e.src,root))).toString('base64');
await fs.writeFile(new URL('figma/code.js',root),'const SLIDES='+JSON.stringify(slides)+';\nconst IMAGES='+JSON.stringify(embedded)+';\n'+await fs.readFile(new URL('figma/runtime.js',root),'utf8'));
console.log(`Built ${slides.length} slides with ${Object.keys(embedded).length} embedded assets.`);
